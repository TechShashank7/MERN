MONGODB_URI = "mongodb+srv://TechShashank:Zme41oKV34gRoSNZ@cluster1.ef8o9xn.mongodb.net/?appName=Cluster1&retryWrites=true&w=majority";

const express = require("express");
const mongoose = require("mongoose");

const app = express();
const PORT = 3000;

mongoose.connect(process.env.MONGODB_URI)
.then(() => {
    console.log("Connected to MongoDB");
})
.catch((err) => {
    console.err("Error connecting to MongoDB: ", err.message);
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});